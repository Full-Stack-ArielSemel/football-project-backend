package com.dev.controllers;

import com.dev.objects.Player;
import com.dev.objects.Team;
import com.dev.utils.Persist;
import com.dev.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.util.List;

@RestController
public class PlayerController {

    @Autowired
    private Persist persist;

    @Autowired
    private Utils util;

    @PostConstruct
    public void init () {}

    @RequestMapping(value = "/update-score-player",method = RequestMethod.POST)
    public void updateScore(int playerID){
        persist.updateScorePlayer(playerID);
    }

    @RequestMapping(value = "/get-all-players-by-team-id", method = RequestMethod.GET)
    public List<Player> getAllPlayersBYTeamID(int teamID){

        return persist.getAllPlayersByTeamID(teamID);
    }

    @RequestMapping(value = "/get-all-players", method = RequestMethod.GET)
    public List<Player> getAllPlayers(){
        return persist.getAllPlayers();
    }
}
