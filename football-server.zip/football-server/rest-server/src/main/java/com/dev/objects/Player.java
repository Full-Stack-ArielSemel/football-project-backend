package com.dev.objects;

import javax.persistence.*;

@Entity
@Table(name = "players")
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Integer player_id;

    @Column
    private String name;

    @Column
    private String img;

    @Column
    private int goals;

    @ManyToOne
    @JoinColumn(name ="team_id")
    private Team team;

    @ManyToOne
    @JoinColumn(name = "league_id")
    private League league;

    public Player(){}

    public Player(Integer player_id, String name, String img, int goals, Team team,League league) {
        this.player_id = player_id;
        this.name = name;
        this.img = img;
        this.goals = goals;
        this.team = team;
        this.league=league;
    }

    public Player(String name, String img, int goals, Team team,League league) {
        this.name = name;
        this.img = img;
        this.goals = goals;
        this.team = team;
        this.league = league;
    }

    public Player(String name, String img, int goals,League league) {
        this.name = name;
        this.img = img;
        this.goals = goals;
        this.league = league;
    }

    public Integer getPlayer_id() {
        return player_id;
    }

    public void setPlayer_id(Integer player_id) {
        this.player_id = player_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public League getLeague() {
        return league;
    }

    public void setLeague(League league) {
        this.league = league;
    }
}
