package com.dev.responses;

public class LiveGamesByUserResponse extends BasicResponse {


}
