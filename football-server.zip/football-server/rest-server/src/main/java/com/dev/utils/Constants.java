package com.dev.utils;

public class Constants {
    public static final int MINIMAL_PASSWORD_LENGTH = 8;

    public static final int MINIMAL_USERNAME_LENGTH = 6;

}
