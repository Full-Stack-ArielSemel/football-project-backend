package com.dev.utils;

public enum MatchType {

    DRAW ,
    WIN,
    LOSE
}
